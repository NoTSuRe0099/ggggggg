﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApplication1
{
    class Program
    {
        static void Main(string[] args)
        {
      
            int num1, num2, num3, sum, sub, square1, square2, square3 ;

        
            Console.WriteLine("Enter the First number : ");
            num1 = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the Second number : ");
            num2 = int.Parse(Console.ReadLine());

            Console.WriteLine("Enter the Third number : ");
            num3 = int.Parse(Console.ReadLine());

            Console.WriteLine("\n");

            sum = num1 + num2 + num3;
            // SUM OF ALL THREE NUMBERS
            Console.WriteLine("Sum Of All Three Numbers is: " + sum + "\n" );

            //Largets Number
            if (num1 > num2)
            {

                if (num1 > num3)
                {
                    Console.WriteLine("largest number : " + num1);
                }
                else
                {
                    Console.WriteLine("largest number : " + num3);
                }
            }
            else
            {
                if (num2 > num3)
                {
                    Console.WriteLine("largest number : " + num2);
                }
                else
                {
                    Console.WriteLine("largest number : " + num3);
                 
                }
            }

            Console.WriteLine("\n");

            //Substraction Of Three Numbers

            sub = num1 - num2 - num3;

            Console.WriteLine("Substraction Of All Three Numbers: " + sub + " \n");

            //Square Of All three number

            Console.WriteLine("Squares Of All Numbers");
    

            square1 = num1 * num1;
            Console.WriteLine("Square OF Num 1 = " + square1);

            square2 = num2 * num2;
            Console.WriteLine("Square OF Num 1 = " + square2);

            square3 = num3 * num3;


            Console.WriteLine("Square OF Num 1 = " + square3);

            Console.WriteLine("Sum OF All there Square Of All Numbers = " + (square1 + square2 + square3) );

            Console.ReadLine();
        }
    }
}
